'use strict';

angular.module('contactsApp')
  .service('ContactsArray', function() {
    this.index,
    this.isEditing = false,
    this.currentContact,
    this.contacts = [
      {
        'first_name': 'Christina',
        'last_name': 'Stewart',
        'description': 'I am a coder',
        'phone': '123-455-6789',
        'email': 'c@g.com'
      },
      {
        'first_name': 'Austin',
        'last_name': 'BlackEye',
        'description': 'I am in advertising',
        'phone': '123-455-6789',
        'email': 'c@g.com'
      },
      {
        'first_name': 'Lauren',
        'last_name': 'ChocolatePants',
        'description': 'I am a CEO    ',
        'phone': '123-455-6789',
        'email': 'c@g.com'
      }
    ];
  })

  .directive('contactDetail', function() {
    return {
      templateUrl: 'app/main/detail.html',
      restrict: 'A',
      scope: {
        currentContact: '='
      },
    }
  })

  .controller('MainCtrl', function (ContactsArray) {
    var self = this;

    self.contacts = ContactsArray.contacts;

    self.editing = function(contact, index) {
      ContactsArray.isEditing = true;
      ContactsArray.currentContact = contact;
      ContactsArray.index = index;
    }
  });
