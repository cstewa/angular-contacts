'use strict';

angular.module('contactsApp')
  .controller('NavbarCtrl', function ($scope) {
    $scope.date = new Date();
  });
